#include "Menus.h"
#include "../World/WorldMap.h"
#include "../Systems/SaveLoad.h"

// Character creation variables
char playerName[32] = "Hero";
int nameCursorPos = 4; // Length of "Hero"
bool isEditingName = false;
int raceSelected = 1; // 0 = Dog, 1 = Cat (default Cat)

void TitleUpdate()
{
    if (IsKeyPressed(KEY_DOWN) || IsKeyPressed(KEY_S))
        selectedOption = (selectedOption + 1) % 3;
    
    if (IsKeyPressed(KEY_UP) || IsKeyPressed(KEY_W))
        selectedOption = (selectedOption - 1 + 3) % 3;
    
    if (IsKeyPressed(KEY_ENTER) || IsKeyPressed(KEY_SPACE)) {
        if (selectedOption == 0) {
            currentState = STATE_MAPSIZE;
        } else if (selectedOption == 1) {
            if (SaveFileExists(0) || SaveFileExists(1) || SaveFileExists(2))
                currentState = STATE_LOAD_MENU;
        } else if (selectedOption == 2) {
            shouldQuit = true;
        }
    }
}

void TitleDraw()
{
    int screenWidth = GetScreenWidth();
    int screenHeight = GetScreenHeight();
    
    // Version in bottom left
    const char* version = "v0.0.7";
    DrawTextEx(GetFontDefault(), version, (Vector2){ 10.0f, (float)(screenHeight - 25) }, 16, 1, DARKGRAY);
    
    // Title
    const char* title = "BoneBound";
    Vector2 titleSize = MeasureTextEx(GetFontDefault(), title, 48, 2);
    Vector2 titlePos = {
        screenWidth / 2.0f - titleSize.x / 2.0f,
        screenHeight / 4.0f
    };
    DrawTextEx(GetFontDefault(), title, titlePos, 48, 2, YELLOW);
    
    // Options
    const char* options[] = {"NEW GAME", "LOAD GAME", "QUIT"};
    bool hasSaves = SaveFileExists(0) || SaveFileExists(1) || SaveFileExists(2);
    
    for (int i = 0; i < 3; i++) {
        Color color = (i == selectedOption) ? YELLOW : WHITE;
        
        if (i == 1 && !hasSaves)
            color = GRAY;
        
        Vector2 textSize = MeasureTextEx(GetFontDefault(), options[i], 32, 1);
        Vector2 textPos = {
            screenWidth / 2.0f - textSize.x / 2.0f,
            screenHeight / 2.0f + i * 50.0f
        };
        
        bool isGrayedOut = (i == 1 && !hasSaves);
        if (i == selectedOption && !isGrayedOut) {
            DrawText(">", textPos.x - 21, textPos.y, 32, YELLOW);
            DrawText("<", textPos.x + textSize.x + 10, textPos.y, 32, YELLOW);
        }
        
        DrawTextEx(GetFontDefault(), options[i], textPos, 32, 1, color);
    }
    
    // Instructions
    const char* inst = "UP/DOWN to navigate, ENTER to select";
    Vector2 instSize = MeasureTextEx(GetFontDefault(), inst, 20, 1);
    Vector2 instPos = {
        screenWidth / 2.0f - instSize.x / 2.0f,
        (float)screenHeight - 50.0f
    };
    DrawTextEx(GetFontDefault(), inst, instPos, 20, 1, LIGHTGRAY);
}

void MapSizeUpdate()
{
    if (IsKeyPressed(KEY_DOWN) || IsKeyPressed(KEY_S))
        selectedOption = (selectedOption + 1) % NUM_SIZES;
    
    if (IsKeyPressed(KEY_UP) || IsKeyPressed(KEY_W))
        selectedOption = (selectedOption - 1 + NUM_SIZES) % NUM_SIZES;
    
    if (IsKeyPressed(KEY_ENTER) || IsKeyPressed(KEY_SPACE)) {
        // Store selected map size and move to character creation
        currentState = STATE_CHARACTER_CREATION;
        // Reset character creation variables
        strcpy(playerName, "Hero");
        nameCursorPos = 4;
        isEditingName = false;
        raceSelected = 1; // Default to Cat
    }
    
    if (IsKeyPressed(KEY_BACKSPACE))
        currentState = STATE_TITLE;
}

void MapSizeDraw()
{
    int screenWidth = GetScreenWidth();
    int screenHeight = GetScreenHeight();
    
    // Version in bottom left
    const char* version = "v0.0.7";
    DrawTextEx(GetFontDefault(), version, (Vector2){ 10.0f, (float)(screenHeight - 25) }, 16, 1, DARKGRAY);
    
    // Title
    const char* title = "Map Size";
    Vector2 titleSize = MeasureTextEx(GetFontDefault(), title, 48, 2);
    Vector2 titlePos = {
        screenWidth / 2.0f - titleSize.x / 2.0f,
        screenHeight / 6.0f
    };
    DrawTextEx(GetFontDefault(), title, titlePos, 48, 2, YELLOW);
    
    // Selected info
    const char* info = TextFormat("Selected: %s (%dx%d)", 
        mapSizes[selectedOption].name,
        mapSizes[selectedOption].width,
        mapSizes[selectedOption].height);
    Vector2 infoSize = MeasureTextEx(GetFontDefault(), info, 22, 1);
    Vector2 infoPos = {
        screenWidth / 2.0f - infoSize.x / 2.0f,
        screenHeight / 3.0f
    };
    DrawTextEx(GetFontDefault(), info, infoPos, 22, 1, LIGHTGRAY);
    
    // Options
    const char* names[] = {"TINY", "SMALL", "MEDIUM", "LARGE", "HUGE", "GIGANTIC"};
    
    for (int i = 0; i < NUM_SIZES; i++) {
        Color color = (i == selectedOption) ? YELLOW : WHITE;
        
        char text[50];
        sprintf(text, "%s (%dx%d)", names[i], mapSizes[i].width, mapSizes[i].height);
        
        Vector2 textSize = MeasureTextEx(GetFontDefault(), text, 28, 1);
        Vector2 textPos = {
            screenWidth / 2.0f - textSize.x / 2.0f,
            screenHeight / 2.0f + i * 40.0f
        };
        
        if (i == selectedOption) {
            DrawText(">", textPos.x - 21, textPos.y, 28, YELLOW);
            DrawText("<", textPos.x + textSize.x + 10, textPos.y, 28, YELLOW);
        }
        
        DrawTextEx(GetFontDefault(), text, textPos, 28, 1, color);
    }
    
    // Instructions
    const char* inst = "ENTER to continue, BACKSPACE to return";
    Vector2 instSize = MeasureTextEx(GetFontDefault(), inst, 16, 1);
    Vector2 instPos = {
        screenWidth / 2.0f - instSize.x / 2.0f,
        (float)screenHeight - 80.0f
    };
    DrawTextEx(GetFontDefault(), inst, instPos, 16, 1, LIGHTGRAY);
}

void CharacterCreationUpdate()
{
    if (!isEditingName) {
        // Navigation between options (Race selection)
        if (IsKeyPressed(KEY_DOWN) || IsKeyPressed(KEY_S)) {
            selectedOption = (selectedOption + 1) % 3; // 0=Name, 1=Race, 2=Confirm
        }
        if (IsKeyPressed(KEY_UP) || IsKeyPressed(KEY_W)) {
            selectedOption = (selectedOption - 1 + 3) % 3;
        }
        
        // Enter sub-menus
        if (IsKeyPressed(KEY_ENTER) || IsKeyPressed(KEY_SPACE)) {
            if (selectedOption == 0) {
                // Start editing name
                isEditingName = true;
                nameCursorPos = strlen(playerName);
            } else if (selectedOption == 1) {
                // Toggle race
                raceSelected = (raceSelected + 1) % 2; // 0=Dog, 1=Cat
            } else if (selectedOption == 2) {
                // Confirm and start game
                // Set player's race
                player.isCat = (raceSelected == 1);
                // Copy name to player (you'll need to add a name field to player)
                strcpy(player.name, playerName);
                
                // Generate world map with previously selected size
                GenerateWorldMap(mapSizes[selectedOption].width, mapSizes[selectedOption].height);
                currentState = STATE_PLAYING;
            }
        }
    } else {
        // Name editing mode
        int key = GetCharPressed();
        
        // Handle backspace
        if (IsKeyPressed(KEY_BACKSPACE) && nameCursorPos > 0) {
            nameCursorPos--;
            playerName[nameCursorPos] = '\0';
        }
        
        // Handle character input
        while (key > 0) {
            if ((key >= 32) && (key <= 125) && nameCursorPos < 31) {
                playerName[nameCursorPos] = (char)key;
                nameCursorPos++;
                playerName[nameCursorPos] = '\0';
            }
            key = GetCharPressed();
        }
        
        // Press ENTER to finish editing
        if (IsKeyPressed(KEY_ENTER)) {
            if (nameCursorPos == 0) {
                // If name is empty, set default
                strcpy(playerName, "Hero");
                nameCursorPos = 4;
            }
            isEditingName = false;
        }
        
        // Press ESC to cancel editing
        if (IsKeyPressed(KEY_ESCAPE)) {
            strcpy(playerName, "Hero");
            nameCursorPos = 4;
            isEditingName = false;
        }
    }
    
    // Back to map size selection
    if (IsKeyPressed(KEY_BACKSPACE) && !isEditingName) {
        currentState = STATE_MAPSIZE;
        selectedOption = 0;
    }
}

void CharacterCreationDraw()
{
    int screenWidth = GetScreenWidth();
    int screenHeight = GetScreenHeight();
    
    // Version in bottom left
    const char* version = "v0.0.7";
    DrawTextEx(GetFontDefault(), version, (Vector2){ 10.0f, (float)(screenHeight - 25) }, 16, 1, DARKGRAY);
    
    // Title
    const char* title = "Character Creation";
    Vector2 titleSize = MeasureTextEx(GetFontDefault(), title, 48, 2);
    Vector2 titlePos = {
        screenWidth / 2.0f - titleSize.x / 2.0f,
        screenHeight / 6.0f
    };
    DrawTextEx(GetFontDefault(), title, titlePos, 48, 2, YELLOW);
    
    // ===== NAME SECTION =====
    int sectionSpacing = 60; // Space between sections
    
    // Name label
    const char* nameLabel = "Name:";
    Vector2 nameLabelSize = MeasureTextEx(GetFontDefault(), nameLabel, 24, 1);
    DrawTextEx(GetFontDefault(), nameLabel, 
        (Vector2){ screenWidth / 2.0f - 200.0f, screenHeight / 3.0f }, 24, 1, WHITE);
    
    // Name input box - 20 pixels to the right of the label
    Rectangle nameBox = { 
        screenWidth / 2.0f - 100.0f, 
        screenHeight / 3.0f - 5, 
        200, 
        30 
    };
    
    if (selectedOption == 0 && !isEditingName) {
        DrawRectangleLinesEx(nameBox, 2, YELLOW);
    } else {
        DrawRectangleLinesEx(nameBox, 1, LIGHTGRAY);
    }
    
    // Name text inside box
    DrawTextEx(GetFontDefault(), playerName, 
        (Vector2){ screenWidth / 2.0f - 95.0f, screenHeight / 3.0f }, 20, 1, WHITE);
    
    // Name cursor when editing
    if (isEditingName) {
        float cursorX = screenWidth / 2.0f - 95.0f + MeasureTextEx(GetFontDefault(), playerName, 20, 1).x;
        DrawTextEx(GetFontDefault(), "_", 
            (Vector2){ cursorX, screenHeight / 3.0f }, 20, 1, YELLOW);
    }
    
    // ===== RACE SECTION =====
    // Race label
    const char* raceLabel = "Race:";
    Vector2 raceLabelSize = MeasureTextEx(GetFontDefault(), raceLabel, 24, 1);
    DrawTextEx(GetFontDefault(), raceLabel, 
        (Vector2){ screenWidth / 2.0f - 200.0f, screenHeight / 3.0f + sectionSpacing }, 24, 1, WHITE);
    
    // Dog option - 20 pixels to the right of the label
    Color dogColor = (raceSelected == 0) ? YELLOW : WHITE;
    Vector2 dogPos = { screenWidth / 2.0f - 100.0f, screenHeight / 3.0f + sectionSpacing - 5 };
    DrawTextEx(GetFontDefault(), "Dog", dogPos, 28, 1, dogColor);
    
    // Cat option - 40 pixels to the right of Dog (20px gap)
    Color catColor = (raceSelected == 1) ? YELLOW : WHITE;
    Vector2 catPos = { screenWidth / 2.0f - 20.0f, screenHeight / 3.0f + sectionSpacing - 5 };
    DrawTextEx(GetFontDefault(), "Cat", catPos, 28, 1, catColor);
    
    // Race selector highlight boxes
    if (selectedOption == 1 && !isEditingName) {
        if (raceSelected == 0) {
            DrawRectangleLines(screenWidth / 2.0f - 105, screenHeight / 3.0f + sectionSpacing - 10, 60, 35, YELLOW);
        } else {
            DrawRectangleLines(screenWidth / 2.0f - 25, screenHeight / 3.0f + sectionSpacing - 10, 60, 35, YELLOW);
        }
    }
    
    // Race descriptions (centered under the options)
    const char* dogDesc = "Dogs have keen smell and loyalty bonuses";
    const char* catDesc = "Cats are agile and have night vision";
    
    float descX = screenWidth / 2.0f - 200.0f;
    float descY = screenHeight / 3.0f + sectionSpacing + 30;
    
    if (raceSelected == 0) {
        DrawTextEx(GetFontDefault(), dogDesc, (Vector2){ descX, descY }, 14, 1, LIGHTGRAY);
    } else {
        DrawTextEx(GetFontDefault(), catDesc, (Vector2){ descX, descY }, 14, 1, LIGHTGRAY);
    }
    
    // ===== CONFIRM SECTION =====
    // Confirm button - centered with more spacing
    Color confirmColor = (selectedOption == 2 && !isEditingName) ? YELLOW : WHITE;
    Vector2 confirmPos = { screenWidth / 2.0f - 80.0f, screenHeight / 3.0f + sectionSpacing * 2 + 20 };
    DrawTextEx(GetFontDefault(), "Start Adventure", confirmPos, 28, 1, confirmColor);
    
    if (selectedOption == 2 && !isEditingName) {
        DrawText(">", confirmPos.x - 30, confirmPos.y, 28, YELLOW);
        DrawText("<", confirmPos.x + 190, confirmPos.y, 28, YELLOW);
    }
    
    // ===== INSTRUCTIONS =====
    const char* editInst = isEditingName ? 
        "Type your name, ENTER to confirm, ESC to cancel" : 
        "UP/DOWN to navigate, ENTER to select, BACKSPACE to go back";
    Vector2 instSize = MeasureTextEx(GetFontDefault(), editInst, 16, 1);
    Vector2 instPos = {
        screenWidth / 2.0f - instSize.x / 2.0f,
        (float)screenHeight - 80.0f
    };
    DrawTextEx(GetFontDefault(), editInst, instPos, 16, 1, LIGHTGRAY);
}

void SaveMenuUpdate()
{
    if (IsKeyPressed(KEY_DOWN) || IsKeyPressed(KEY_S))
        saveSlotSelected = (saveSlotSelected + 1) % 3;
    
    if (IsKeyPressed(KEY_UP) || IsKeyPressed(KEY_W))
        saveSlotSelected = (saveSlotSelected - 1 + 3) % 3;
    
    if (IsKeyPressed(KEY_ENTER) || IsKeyPressed(KEY_SPACE)) {
        SaveGame(saveSlotSelected);
        currentState = STATE_PLAYING;
    }
    
    if (IsKeyPressed(KEY_BACKSPACE) || IsKeyPressed(KEY_ESCAPE)) {
        // Make sure we're returning to a valid state
        if (worldMap != NULL) {
            currentState = STATE_PLAYING;
        } else {
            // If no world map exists, go back to title
            currentState = STATE_TITLE;
            selectedOption = 0;
        }
    }
}

void SaveMenuDraw()
{
    int screenWidth = GetScreenWidth();
    int screenHeight = GetScreenHeight();
    
    // Version in bottom left
    const char* version = "v0.0.7";
    DrawTextEx(GetFontDefault(), version, (Vector2){ 10.0f, (float)(screenHeight - 25) }, 16, 1, DARKGRAY);
    
    // Title
    const char* title = "Save Game";
    Vector2 titleSize = MeasureTextEx(GetFontDefault(), title, 48, 2);
    Vector2 titlePos = {
        screenWidth / 2.0f - titleSize.x / 2.0f,
        screenHeight / 6.0f
    };
    DrawTextEx(GetFontDefault(), title, titlePos, 48, 2, YELLOW);
    
    // Slots
    const char* slots[] = {"Save Slot 1", "Save Slot 2", "Save Slot 3"};
    
    for (int i = 0; i < 3; i++) {
        Color color = (i == saveSlotSelected) ? YELLOW : WHITE;
        
        // Check if save exists to show character info
        bool exists = SaveFileExists(i);
        
        Vector2 textSize = MeasureTextEx(GetFontDefault(), slots[i], 32, 1);
        Vector2 textPos = {
            screenWidth / 2.0f - textSize.x / 2.0f,
            screenHeight / 2.0f + i * 60.0f
        };
        
        if (i == saveSlotSelected) {
            DrawText(">", textPos.x - 21, textPos.y, 32, YELLOW);
            DrawText("<", textPos.x + textSize.x + 10, textPos.y, 32, YELLOW);
        }
        
        DrawTextEx(GetFontDefault(), slots[i], textPos, 32, 1, color);
        
        // Show save info if exists (placeholder)
        if (exists) {
            // Would show character name/level here
        }
    }
}

void LoadMenuUpdate()
{
    if (IsKeyPressed(KEY_DOWN) || IsKeyPressed(KEY_S))
        saveSlotSelected = (saveSlotSelected + 1) % 3;
    
    if (IsKeyPressed(KEY_UP) || IsKeyPressed(KEY_W))
        saveSlotSelected = (saveSlotSelected - 1 + 3) % 3;
    
    if (IsKeyPressed(KEY_ENTER) || IsKeyPressed(KEY_SPACE)) {
        if (SaveFileExists(saveSlotSelected) && LoadGame(saveSlotSelected)) {
            currentState = STATE_PLAYING;
        }
    }
    
    if (IsKeyPressed(KEY_BACKSPACE) || IsKeyPressed(KEY_ESCAPE)) {
        // Make sure we're returning to a valid state
        if (worldMap != NULL) {
            currentState = STATE_PLAYING;
        } else {
            // If no world map exists, go back to title
            currentState = STATE_TITLE;
            selectedOption = 0;
        }
    }
}

void LoadMenuDraw()
{
    int screenWidth = GetScreenWidth();
    int screenHeight = GetScreenHeight();
    
    // Version in bottom left
    const char* version = "v0.0.7";
    DrawTextEx(GetFontDefault(), version, (Vector2){ 10.0f, (float)(screenHeight - 25) }, 16, 1, DARKGRAY);
    
    // Title
    const char* title = "Load Game";
    Vector2 titleSize = MeasureTextEx(GetFontDefault(), title, 48, 2);
    Vector2 titlePos = {
        screenWidth / 2.0f - titleSize.x / 2.0f,
        screenHeight / 6.0f
    };
    DrawTextEx(GetFontDefault(), title, titlePos, 48, 2, YELLOW);
    
    // Slots
    const char* slots[] = {"Load Slot 1", "Load Slot 2", "Load Slot 3"};
    
    for (int i = 0; i < 3; i++) {
        bool exists = SaveFileExists(i);
        Color color = (i == saveSlotSelected && exists) ? YELLOW : (exists ? WHITE : GRAY);
        
        Vector2 textSize = MeasureTextEx(GetFontDefault(), slots[i], 32, 1);
        Vector2 textPos = {
            screenWidth / 2.0f - textSize.x / 2.0f,
            screenHeight / 2.0f + i * 60.0f
        };
        
        if (i == saveSlotSelected && exists) {
            DrawText(">", textPos.x - 21, textPos.y, 32, YELLOW);
            DrawText("<", textPos.x + textSize.x + 10, textPos.y, 32, YELLOW);
        }
        
        DrawTextEx(GetFontDefault(), slots[i], textPos, 32, 1, color);
        
        if (!exists) {
            Vector2 emptySize = MeasureTextEx(GetFontDefault(), "(Empty)", 20, 1);
            Vector2 emptyPos = {
                screenWidth / 2.0f - emptySize.x / 2.0f,
                textPos.y + 35.0f
            };
            DrawTextEx(GetFontDefault(), "(Empty)", emptyPos, 20, 1, GRAY);
        } else {
            // Show save info (would load from save file metadata)
            Vector2 infoPos = {
                screenWidth / 2.0f - 100.0f,
                textPos.y + 30.0f
            };
            DrawTextEx(GetFontDefault(), "Level 1   Hero", infoPos, 14, 1, LIGHTGRAY);
        }
    }
}